Sprite Pack 1
By Eightbitswide

How to load in SPED (Sprite Editor)
-----------------------------------

Load as RGBA8 (Option 2).
Load as Multiple Frames: 24
Pattern is: sp%%.spr
Files numbered from: 1 to 24
